import { Component, OnInit } from '@angular/core';
import { Network } from '../network';
import { Connection } from '../connection';
import { NetworkNode } from '../network.node';
import { NetworkService } from '../network.service';
import { Router } from '@angular/router'

@Component({
  selector: 'app-network-create',
  templateUrl: './network-create.component.html',
  styleUrls: ['./network-create.component.scss']
})
export class NetworkCreateComponent implements OnInit {

  model = new Network();
  submitted = false;
  consensusTypes:string[];

  constructor(private networkService:NetworkService, private router: Router) { }

  ngOnInit() {
    this.consensusTypes = [];
    this.consensusTypes.push("Proof of Audit");
  }

  save(): void {
    this.submitted = true;
    this.model.nodes = [];

    let auditNodeCount = parseInt(this.model.auditNodeCount);
    for (var i = 0 ; i < auditNodeCount; i++) {
      let node = new NetworkNode(`node-${i+1}`, 'audit', `hashcode${i+1}`, `publickey${i+1}`);
      this.model.nodes.push(node);
    }

    let customerNodeCount = parseInt(this.model.customerNodeCount);
    for (var i = 0 ; i < customerNodeCount; i++) {
      let node = new NetworkNode(`node-${i+1}`, 'customer', `hashcode${i+1}`, `publickey${i+1}`);
      this.model.nodes.push(node);
    }

    this.networkService.createNetwork(this.model)
      .subscribe(network => {
        console.log(`Creating links for network:${network.id}`); //
        this.router.navigate(['/network']);
        // this.networkService.createLinks(network.id,
        //                     this.computeLinks(network.nodes))
//          .subscribe( res => this.router.navigate(['/network']));
      });
  }

  private computeLinks(nodes):Connection[] {
    let allPairs:Connection[] = [];
    for (var i = 0; i < nodes.length; i++) {
      for (var j = i + 1; j < nodes.length; j++) {
        let connection = new Connection();
        connection.nodeId1 = nodes[i].id;
        connection.nodeId2 = nodes[j].id;
        allPairs.push(connection);
      }
    }

    return allPairs;
  }

  changeNetworkType(newValue:string):void {
    switch(newValue) {
      case "Mastercard Blockchain":
        this.consensusTypes = [];
        this.consensusTypes.push("Proof of Audit");
        this.consensusTypes.push("Microsoft Coco");
        break;
      case "Ethereum":
        this.consensusTypes = [];
        this.consensusTypes.push("Proof of Work");
        this.consensusTypes.push("Proof of Stake");
        break;
      default:
        this.consensusTypes = [];
        this.consensusTypes.push("Proof of Time Elapsed");
        this.consensusTypes.push("Proof of Authority");
        this.consensusTypes.push("Proof of Audit");
    }
  }
}
