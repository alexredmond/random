import { Connection } from './connection';
import { NetworkNode } from './network.node';

export class NetworkResponse {

  id: number;
  name: string;
  description: string;

  consensusType: string;
  networkType: string;

  nodes:NetworkNode[];
  connections:Connection[];

}
