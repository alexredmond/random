export class Connection {

  id:number;
  connectionName:string;

  nodeId1:number;
  nodeId2:number;

}
