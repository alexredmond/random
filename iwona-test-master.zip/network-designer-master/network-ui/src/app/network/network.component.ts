import { Component, OnInit } from '@angular/core';
import { NetworkService } from '../network.service';
import { Network } from '../network';
import { NetworkNode } from '../network.node';
import { NetworkResponse } from '../network.response';
import { Link } from '../d3';

@Component({
  selector: 'app-network',
  templateUrl: './network.component.html',
  styleUrls: ['./network.component.scss']
})
export class NetworkComponent implements OnInit {

  networks:Network[];
  selectedNetwork: Network;
  watch:string;

  constructor(private networkService: NetworkService) { }

  getNetworks(): void {
    this.networkService.getNetworks()
      .subscribe(networks => this.networks = this.transform(networks));
  }

  ngOnInit() {
    this.getNetworks();
  }

  private transform(networks:NetworkResponse[]):Network[] {

    let nets:Network[] = [];

    networks.forEach( n => {
      let network:Network = new Network();
      network.id = n.id;
      network.name = n.name;
      network.description = n.description;
      network.consensusType = n.consensusType;
      network.networkType = n.networkType;
      network.nodes = n.nodes;
      network.links = [];

      n.connections.forEach( c => {
        let source = network.nodes.find(e => e.id == c.nodeId1);
        let target = network.nodes.find(e => e.id == c.nodeId2);
        let link = new Link(source, target);
        link.index = c.id;

        network.links.push(link);
      });

      nets.push(network);
    });

    console.log(nets);

    return nets;

  }

  onSelect(network: Network): void {
    this.selectedNetwork = network;
    this.watch = network.name;
  }

}
