import { Component, Input } from '@angular/core';
import { Node } from '../../../d3';

@Component({
  selector: '[nodeVisual]',
  template: `
    <svg:g [attr.transform]="'translate(' + node.x + ',' + node.y + ')'">
      <svg:circle
          cx="0"
          cy="0"
          r="23"
          [attr.fill]="getColor()">
      </svg:circle>
      <svg:text text-anchor="middle" stroke-width="2px" dominant-baseline="central">
        {{node.id}}
      </svg:text>
    </svg:g>
  `
})
export class NodeVisualComponent {
  @Input('nodeVisual') node: Node;

  getColor():string {
    if (this.node.nodeType == 'audit') {
      return 'orange';
    } else {
      return 'lightblue';
    }
  }
}
