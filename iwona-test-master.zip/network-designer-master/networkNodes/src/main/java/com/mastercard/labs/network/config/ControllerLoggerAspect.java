package com.mastercard.labs.network.config;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Configuration;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

@Aspect
@Configuration
public class ControllerLoggerAspect {

    private Logger logger = LoggerFactory.getLogger(this.getClass());

    @Before("execution(* com.mastercard.labs.network.web.controller.*.*(..))")
    public void before(JoinPoint joinPoint){
        logger.info("RestController calling method: " + joinPoint.getSignature().toShortString() + "| Args => " + Arrays.asList(joinPoint.getArgs()));
    }
}
