INSERT INTO networkdb.network(id, name, description, networktype, consensustype) VALUES (1, 'MC Chain 1', 'First experiment with MC Blockchain', 'Mastercard Blockchain', 'Proof of Audit') ON CONFLICT DO NOTHING;
INSERT INTO networkdb.network(id, name, description, networktype, consensustype) VALUES (2, 'Ether PoW', 'Ethereum test with Proof of work', 'Ethereum', 'Proof of Work') ON CONFLICT DO NOTHING;

SELECT setval('networkdb.networkseq', (SELECT GREATEST((select nextval('networkdb.networkseq')), 3)));

INSERT INTO networkdb.node(id, networkid, address, description, name, "publickey", nodetype) VALUES (1, 1, md5('hashAddress1'), 'd1', 'node-1', 'pubKey1', 'audit') ON CONFLICT DO NOTHING;
INSERT INTO networkdb.node(id, networkid, address, description, name, "publickey", nodetype) VALUES (2, 1, md5('hashAddress2'), 'd2', 'node-2', 'pubKey2', 'audit') ON CONFLICT DO NOTHING;
INSERT INTO networkdb.node(id, networkid, address, description, name, "publickey", nodetype) VALUES (3, 1, md5('hashAddress3'), 'd3', 'node-3', 'pubKey3', 'audit') ON CONFLICT DO NOTHING;
INSERT INTO networkdb.node(id, networkid, address, description, name, "publickey", nodetype) VALUES (4, 1, md5('hashAddress4'), 'd4', 'node-4', 'pubKey4', 'audit') ON CONFLICT DO NOTHING;
INSERT INTO networkdb.node(id, networkid, address, description, name, "publickey", nodetype) VALUES (5, 1, md5('hashAddress5'), 'd5', 'node-5', 'pubKey5', 'audit') ON CONFLICT DO NOTHING;
INSERT INTO networkdb.node(id, networkid, address, description, name, "publickey", nodetype) VALUES (6, 1, md5('hashAddress6'), 'd6', 'node-6', 'pubKey6', 'audit') ON CONFLICT DO NOTHING;
INSERT INTO networkdb.node(id, networkid, address, description, name, "publickey", nodetype) VALUES (7, 1, md5('hashAddress6'), 'd7', 'node-7', 'pubKey7', 'audit') ON CONFLICT DO NOTHING;
INSERT INTO networkdb.node(id, networkid, address, description, name, "publickey", nodetype) VALUES (8, 1, md5('hashAddress8'), 'd8', 'node-8', 'pubKey8', 'customer') ON CONFLICT DO NOTHING;
INSERT INTO networkdb.node(id, networkid, address, description, name, "publickey", nodetype) VALUES (9, 1, md5('hashAddress9'), 'd9', 'node-9', 'pubKey9', 'customer') ON CONFLICT DO NOTHING;
INSERT INTO networkdb.node(id, networkid, address, description, name, "publickey", nodetype) VALUES (10, 1, md5('hashAddress10'), 'd10', 'node-10', 'pubKey10', 'customer') ON CONFLICT DO NOTHING;

INSERT INTO networkdb.node(id, networkid, address, description, name, "publickey", nodetype) VALUES (12, 2, md5('hashAddress12'), 'd12', 'node-12', 'pubKey12', 'customer') ON CONFLICT DO NOTHING;
INSERT INTO networkdb.node(id, networkid, address, description, name, "publickey", nodetype) VALUES (13, 2, md5('hashAddress13'), 'd13', 'node-13', 'pubKey13', 'customer') ON CONFLICT DO NOTHING;
INSERT INTO networkdb.node(id, networkid, address, description, name, "publickey", nodetype) VALUES (14, 2, md5('hashAddress14'), 'd14', 'node-14', 'pubKey14', 'customer') ON CONFLICT DO NOTHING;


SELECT setval('networkdb.nodeseq', (SELECT GREATEST((select nextval('networkdb.nodeseq')), 14)));


INSERT INTO networkdb.connections (id, networkid, nodeid1, nodeid2, name) VALUES (1, 1, 1, 2, 'link-1');
INSERT INTO networkdb.connections (id, networkid, nodeid1, nodeid2, name) VALUES (2, 1, 1, 3, 'link-2');
INSERT INTO networkdb.connections (id, networkid, nodeid1, nodeid2, name) VALUES (3, 1, 1, 4, 'link-3');
INSERT INTO networkdb.connections (id, networkid, nodeid1, nodeid2, name) VALUES (4, 1, 1, 5, 'link-4');
INSERT INTO networkdb.connections (id, networkid, nodeid1, nodeid2, name) VALUES (5, 1, 1, 6, 'link-5');
INSERT INTO networkdb.connections (id, networkid, nodeid1, nodeid2, name) VALUES (6, 1, 1, 7, 'link-6');
INSERT INTO networkdb.connections (id, networkid, nodeid1, nodeid2, name) VALUES (7, 1, 2, 3, 'link-7');
INSERT INTO networkdb.connections (id, networkid, nodeid1, nodeid2, name) VALUES (8, 1, 2, 4, 'link-8');
INSERT INTO networkdb.connections (id, networkid, nodeid1, nodeid2, name) VALUES (9, 1, 2, 5, 'link-9');
INSERT INTO networkdb.connections (id, networkid, nodeid1, nodeid2, name) VALUES (10, 1, 2, 6, 'link-10');
INSERT INTO networkdb.connections (id, networkid, nodeid1, nodeid2, name) VALUES (11, 1, 2, 7, 'link-11');
INSERT INTO networkdb.connections (id, networkid, nodeid1, nodeid2, name) VALUES (12, 1, 3, 4, 'link-12');
INSERT INTO networkdb.connections (id, networkid, nodeid1, nodeid2, name) VALUES (13, 1, 3, 5, 'link-13');
INSERT INTO networkdb.connections (id, networkid, nodeid1, nodeid2, name) VALUES (14, 1, 3, 6, 'link-14');
INSERT INTO networkdb.connections (id, networkid, nodeid1, nodeid2, name) VALUES (15, 1, 3, 7, 'link-15');
INSERT INTO networkdb.connections (id, networkid, nodeid1, nodeid2, name) VALUES (16, 1, 4, 5, 'link-16');
INSERT INTO networkdb.connections (id, networkid, nodeid1, nodeid2, name) VALUES (17, 1, 4, 6, 'link-17');
INSERT INTO networkdb.connections (id, networkid, nodeid1, nodeid2, name) VALUES (18, 1, 4, 7, 'link-18');
INSERT INTO networkdb.connections (id, networkid, nodeid1, nodeid2, name) VALUES (19, 1, 5, 6, 'link-19');
INSERT INTO networkdb.connections (id, networkid, nodeid1, nodeid2, name) VALUES (20, 1, 5, 7, 'link-20');
-- linking customer nodes
INSERT INTO networkdb.connections (id, networkid, nodeid1, nodeid2, name) VALUES (21, 1, 1, 8, 'link-21');
INSERT INTO networkdb.connections (id, networkid, nodeid1, nodeid2, name) VALUES (22, 1, 6, 9, 'link-22');
INSERT INTO networkdb.connections (id, networkid, nodeid1, nodeid2, name) VALUES (23, 1, 3, 10, 'link-23');


-- Link for Ethereum network
INSERT INTO networkdb.connections (id, networkid, nodeid1, nodeid2, name) VALUES (24, 2, 12, 13, 'link-24');
INSERT INTO networkdb.connections (id, networkid, nodeid1, nodeid2, name) VALUES (25, 2, 12, 14, 'link-25');
INSERT INTO networkdb.connections (id, networkid, nodeid1, nodeid2, name) VALUES (26, 2, 13, 14, 'link-26');

SELECT setval('networkdb.connectionseq', (SELECT GREATEST((select nextval('networkdb.connectionseq')), 27)));
