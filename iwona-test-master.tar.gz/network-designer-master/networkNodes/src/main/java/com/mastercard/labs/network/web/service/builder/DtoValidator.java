package com.mastercard.labs.network.web.service.builder;

import com.mastercard.labs.network.web.businessobject.Connection;
import com.mastercard.labs.network.web.repository.entity.ConnectionEntity;
import com.mastercard.labs.network.web.repository.entity.NodeEntity;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import java.util.*;
import java.util.stream.Collectors;

@Component
public class DtoValidator {

    public List<ConnectionEntity> filterConnectionsForCurrentNode(List<ConnectionEntity> networkConnectionEntityList, Long currentNodeId) {
        return networkConnectionEntityList.stream()
                .filter(entity -> (currentNodeId.equals(entity.getNodeid1()) || currentNodeId.equals(entity.getNodeid2())))
                .collect(Collectors.toList());
    }

    public boolean verifyConnectionEmpty(Connection connection, List<ConnectionEntity> networkConnectionList) {
        List<ConnectionEntity> connectionsWithNode1 = filterConnectionsForCurrentNode(networkConnectionList, connection.getNodeId1());
        List<ConnectionEntity> connectionsWithNode1and2 = filterConnectionsForCurrentNode(connectionsWithNode1, connection.getNodeId2());
        return CollectionUtils.isEmpty(connectionsWithNode1and2);
    }

    public List<Connection> filterInvalidDto(List<Connection> connectionList) {
        List<Connection> validConnectioDtos = connectionList.stream()
                .filter(dto -> dto.getNodeId1() != null)
                .filter(dto -> dto.getNodeId2() != null)
                .filter(dto -> !dto.getNodeId1().equals(dto.getNodeId2()))
                .collect(Collectors.toList());
        return validConnectioDtos;
    }

    public boolean validateNodeInNetwork(Long networkId, Long nodeId, List<NodeEntity> networkNodeList) {
        if (nodeId != null) {
            List<NodeEntity> nodeInNetwork = networkNodeList.stream()
                    .filter(nod -> nodeId.equals(nod.getId()))
                    .collect(Collectors.toList());
            return nodeInNetwork.size() > 0;
        }
        return true;
    }

    public List<Connection> filterInvalidNodeIdForNetwork(List<NodeEntity> networkNodeList, List<Connection> validDtos) {
        List<Long> nodeIdsInNetworkList = networkNodeList.stream()
                .map(nod -> nod.getId())
                .collect(Collectors.toList());

        List<Connection> validDtosInNetwork = validDtos.stream()
                .filter(conDto -> (nodeIdsInNetworkList.contains(conDto.getNodeId1()) && nodeIdsInNetworkList.contains(conDto.getNodeId2())))
                .collect(Collectors.toList());

        return validDtosInNetwork;
    }

    public void filterDuplicateEntities(List<ConnectionEntity> conEntities) {
        Map<Long, List<Long>> nodeConnection = new HashMap<>();
        for (Iterator<ConnectionEntity> iter = conEntities.listIterator(); iter.hasNext(); ) {
            ConnectionEntity conEnt = iter.next();
            List<Long> existingNodesConnected = nodeConnection.get(conEnt.getNodeid1());
            if (existingNodesConnected == null) {
                existingNodesConnected = new ArrayList<>();
                nodeConnection.put(conEnt.getNodeid1(), existingNodesConnected);
            }
            if (existingNodesConnected.contains(conEnt.getNodeid2())) {
                iter.remove();
            }else{
                existingNodesConnected.add(conEnt.getNodeid2());
            }
        }
    }

}
