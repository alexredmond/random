/*
 * Copyright (c) 2018 Mastercard. All rights reserved.
 */

package com.mastercard.labs.network.web.repository.entity;


import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

import javax.persistence.*;


@Entity
@Table(name = "Network")
public class NetworkEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "network_generator")
    @SequenceGenerator(name = "network_generator", sequenceName = "networkseq", allocationSize = 1)
    private Long id;
    private String name;
    private String description;
    private String consensustype;
    private String networktype;


    public NetworkEntity() {
    }

    public NetworkEntity(Long id, String name, String description, String consensustype, String networktype) {
        this.id = id;
        this.name = name;
        this.description = description;
        this.consensustype = consensustype;
        this.networktype = networktype;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getConsensustype() {
        return consensustype;
    }

    public void setConsensustype(String consensustype) {
        this.consensustype = consensustype;
    }

    public String getNetworktype() {
        return networktype;
    }

    public void setNetworktype(String networktype) {
        this.networktype = networktype;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this, ToStringStyle.SHORT_PREFIX_STYLE).toString();
    }

}
