package com.mastercard.labs.network.web.service.builder;

import com.mastercard.labs.network.web.businessobject.Connection;
import com.mastercard.labs.network.web.businessobject.Node;
import com.mastercard.labs.network.web.repository.entity.ConnectionEntity;
import com.mastercard.labs.network.web.repository.entity.NodeEntity;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import java.util.*;
import java.util.stream.Collectors;

@Component
public class DtoBuilder {

    @Autowired
    private DtoValidator dtoValidator;

    public ConnectionEntity prepareEntity(Connection connection, Long networkId) {
        if (connection.getNodeId1() == null || connection.getNodeId2() == null) {
            throw new IllegalArgumentException("Both NodeId1 and NodeId2 required");
        }
        if (connection.getNodeId1().equals(connection.getNodeId2())) {
            throw new IllegalArgumentException("NodeId1 and NodeId2 cannot be eual");
        }
        Long nodeId1;
        Long nodeId2;
        int retval = connection.getNodeId1().compareTo(connection.getNodeId2());
        if (retval <= 0) {
            nodeId1 = connection.getNodeId1();
            nodeId2 = connection.getNodeId2();
        } else {
            nodeId1 = connection.getNodeId2();
            nodeId2 = connection.getNodeId1();
        }
        ConnectionEntity connectionEntity = new ConnectionEntity(null, networkId, nodeId1, nodeId2, connection.getConnectionName());
        return connectionEntity;
    }

    public List<Connection> buildNodeConnections(List<ConnectionEntity> networkConnectionEntityList, Long currentNodeId) {
        if (CollectionUtils.isEmpty(networkConnectionEntityList)) {
            return new ArrayList<>();
        }
        List<ConnectionEntity> nodeConnectionList = dtoValidator.filterConnectionsForCurrentNode(networkConnectionEntityList, currentNodeId);

        List<Connection> connectionDtos = mapConnectionEntitiesToDto(nodeConnectionList);
        return connectionDtos;
    }


    public List<Connection> mapConnectionEntitiesToDto(List<ConnectionEntity> connectionEntities) {
        if (CollectionUtils.isEmpty(connectionEntities)) {
            return new ArrayList<>();
        }
        List<Connection> connectionDtoList = connectionEntities.stream()
                .map(n -> new Connection(n.getId(), n.getNodeid1(), n.getNodeid2(), n.getName()))
                .collect(Collectors.toList());
        return connectionDtoList;
    }


    public List<Node> mapNodeEntitiesToDto(List<NodeEntity> nodeEntities, List<ConnectionEntity> connectionEntityList) {
        if (CollectionUtils.isEmpty(nodeEntities)) {
            return new ArrayList<>();
        }
        List<Node> nodeDtoList = nodeEntities.stream()
                .map(n -> {
                    Node nodeDto = new Node(n.getId(), n.getName(), n.getDescription(), n.getAddress(), n.getPublickey(), n.getNodetype());
                    nodeDto.setNodeConnections(buildNodeConnections(connectionEntityList, n.getId()));
                    return nodeDto;
                })
                .collect(Collectors.toList());
        return nodeDtoList;
    }

    public List<ConnectionEntity> prepareConnectionList(List<NodeEntity> nodesCreated, Long networkId) {
        if (CollectionUtils.isEmpty(nodesCreated)) {
            return new ArrayList<>();
        }
        if (nodesCreated.size() < 2) {
            return new ArrayList<>();
        }
        List<ConnectionEntity> connectionsToCreate = new ArrayList<>();
        for (int i = 0; i < nodesCreated.size(); i++) {
            for (int j = (i + 1); j < nodesCreated.size(); j++) {
                NodeEntity n1 = nodesCreated.get(i);
                NodeEntity n2 = nodesCreated.get(j);
                ConnectionEntity newConnectionEntity = new ConnectionEntity(null, networkId, n1.getId(), n2.getId(), "link-" + n1.getId() + "-" + n2.getId());
                connectionsToCreate.add(newConnectionEntity);
            }
        }
        return connectionsToCreate;
    }

}
