package com.mastercard.labs.network.web.service;

import com.mastercard.labs.network.web.businessobject.Connection;
import com.mastercard.labs.network.web.businessobject.Network;
import com.mastercard.labs.network.web.businessobject.Node;
import com.mastercard.labs.network.web.repository.*;
import com.mastercard.labs.network.web.repository.entity.ConnectionEntity;
import com.mastercard.labs.network.web.repository.entity.NetworkEntity;
import com.mastercard.labs.network.web.repository.entity.NodeEntity;
import com.mastercard.labs.network.web.service.builder.DtoBuilder;
import com.mastercard.labs.network.web.service.builder.DtoValidator;
import com.mastercard.labs.network.web.service.exception.AddingConnectionException;
import com.mastercard.labs.network.web.service.exception.NetworkNotFoundException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
@Transactional
public class NetworkService {

    private Logger logger = LoggerFactory.getLogger(NetworkService.class);

    @Autowired
    private NetworkRepository networkRepository;
    @Autowired
    private NodeRepository nodeRepository;
    @Autowired
    private ConnectionRepository connectionRepository;
    @Autowired
    private DtoBuilder dtoBuilder;
    @Autowired
    private DtoValidator dtoValidator;


    public List<Network> getAllNetworks() {
        List<NetworkEntity> networkList = networkRepository.findAll();

        List<Network> networkDtoList =
                networkList.stream()
                        .map(n -> new Network(n.getId(), n.getName(), n.getDescription(), n.getConsensustype(), n.getNetworktype()))
                        .collect(Collectors.toList());

        networkDtoList.forEach(dto -> {
            dto.setNodes(getNodeList(dto.getId()));
            dto.setConnections(getNetworkConnections(dto.getId()));
        });
        return networkDtoList;
    }

    public Network getNetworkById(Long networkId) {
        Optional<NetworkEntity> network = networkRepository.findById(networkId);
        if (!network.isPresent()) {
            throw new NetworkNotFoundException("No network found: " + networkId);
        }
        NetworkEntity networkEntity = network.get();
        Network networkDto = new Network(networkEntity.getId(), networkEntity.getName(), networkEntity.getDescription(), networkEntity.getConsensustype(), networkEntity.getNetworktype());

        List<NodeEntity> nodeEntities = nodeRepository.findByNetworkid(networkEntity.getId());
        List<ConnectionEntity> connectionEntityList = connectionRepository.findByNetworkid(networkEntity.getId());
        networkDto.setNodes(dtoBuilder.mapNodeEntitiesToDto(nodeEntities, connectionEntityList));
        List<ConnectionEntity> connectionEntities = connectionRepository.findByNetworkid(networkEntity.getId());
        networkDto.setConnections(dtoBuilder.mapConnectionEntitiesToDto(connectionEntities));
        return networkDto;
    }

    public Long createNetwork(Network networkDto) {
        NetworkEntity networkEntity = new NetworkEntity(null, networkDto.getName(), networkDto.getDescription(), networkDto.getConsensusType(), networkDto.getNetworkType());
        NetworkEntity savedNetwork = networkRepository.save(networkEntity);

        List<NodeEntity> nodesCreated = new ArrayList();
        if (!CollectionUtils.isEmpty(networkDto.getNodes())) {
            for (Node nodeDto : networkDto.getNodes()) {
                NodeEntity nodeEntity = new NodeEntity(null, savedNetwork.getId(), nodeDto.getAddress(), nodeDto.getDescription(), nodeDto.getName(), nodeDto.getPublicKey(), nodeDto.getNodeType());
                nodeRepository.save(nodeEntity);
                nodesCreated.add(nodeEntity);
            }
        }

        for(ConnectionEntity connectionEntity: dtoBuilder.prepareConnectionList(nodesCreated, savedNetwork.getId())){
            connectionRepository.save(connectionEntity);
        }

        return savedNetwork.getId();
    }




    public void updateNetwork(Network networkDto, Long networkId) {
        Optional<NetworkEntity> networkOptional = networkRepository.findById(networkId);
        if (!networkOptional.isPresent()) {
            throw new NetworkNotFoundException("No network found: " + networkId);
        }
        NetworkEntity networkEntity = networkOptional.get();
        networkEntity.setName(networkDto.getName());
        networkEntity.setDescription(networkDto.getDescription());
        networkEntity.setConsensustype(networkDto.getConsensusType());
        networkEntity.setNetworktype(networkDto.getNetworkType());
        networkRepository.save(networkEntity);
    }

    public void deleteNetwork(Long networkId) {
        connectionRepository.removeByNetworkid(networkId);
        nodeRepository.removeByNetworkid(networkId);
        networkRepository.deleteById(networkId);
    }

    public List<Node> getNodeList(Long networkId) {
        List<NodeEntity> nodeEntities = nodeRepository.findByNetworkid(networkId);
        List<ConnectionEntity> connectionEntityList = connectionRepository.findByNetworkid(networkId);
        List<Node> nodeDtoList = dtoBuilder.mapNodeEntitiesToDto(nodeEntities, connectionEntityList);
        return nodeDtoList;
    }

    public Node getNode(Long nodeId) {
        Optional<NodeEntity> nodeOptional = nodeRepository.findById(nodeId);
        if (!nodeOptional.isPresent()) {
            throw new NetworkNotFoundException("No node found: " + nodeId);
        }
        NodeEntity nodeEntity = nodeOptional.get();
        Node nodeDto = new Node(nodeEntity.getId(), nodeEntity.getName(), nodeEntity.getDescription(), nodeEntity.getAddress(), nodeEntity.getPublickey(), nodeEntity.getNodetype());
        List<ConnectionEntity> connectionEntityList = connectionRepository.findByNetworkid(nodeEntity.getNetworkid());
        List<ConnectionEntity> nodeConnetions = dtoValidator.filterConnectionsForCurrentNode(connectionEntityList, nodeEntity.getId());
        nodeDto.setNodeConnections(dtoBuilder.mapConnectionEntitiesToDto(nodeConnetions));
        return nodeDto;
    }

    public Long addNode(Node node, Long networkId) {
        NodeEntity nodeEntity = new NodeEntity(null, networkId, node.getAddress(), node.getDescription(), node.getName(), node.getPublicKey(), node.getNodeType());
        NodeEntity savedNode = nodeRepository.save(nodeEntity);

        List<NodeEntity> existingNodes = nodeRepository.findByNetworkid(networkId);
        if (!CollectionUtils.isEmpty(existingNodes)){
            for (NodeEntity exisitngNodeEntity: existingNodes) {
                if(exisitngNodeEntity.getId().equals(savedNode.getId())){
                    continue;
                }
                ConnectionEntity newConnection = new ConnectionEntity(null, networkId, exisitngNodeEntity.getId(),savedNode.getId(), "link-"+exisitngNodeEntity.getId()+"-"+savedNode.getId());
                connectionRepository.save(newConnection);
            }
        }
        return savedNode.getId();
    }

    public void updateNode(Node nodeDto, Long nodeId) {
        Optional<NodeEntity> nodeOptional = nodeRepository.findById(nodeId);
        if (!nodeOptional.isPresent()) {
            throw new NetworkNotFoundException("No node found: " + nodeId);
        }
        NodeEntity nodeEntity = nodeOptional.get();
        nodeEntity.setAddress(nodeDto.getAddress());
        nodeEntity.setDescription(nodeDto.getDescription());
        nodeEntity.setName(nodeDto.getName());
        nodeEntity.setPublickey(nodeDto.getPublicKey());
        nodeEntity.setNodetype(nodeDto.getNodeType());
        nodeRepository.save(nodeEntity);
    }

    public void deleteNode(Long nodeId) {
        connectionRepository.removeByNodeid1(nodeId);
        connectionRepository.removeByNodeid2(nodeId);
        nodeRepository.deleteById(nodeId);
    }

    public List<Connection> getNetworkConnections(Long networkId) {
        List<ConnectionEntity> connectionEntities = connectionRepository.findByNetworkid(networkId);
        List<Connection> connectionDtoList = dtoBuilder.mapConnectionEntitiesToDto(connectionEntities);
        return connectionDtoList;
    }

    public Connection getConnection(Long connectionId) {
        Optional<ConnectionEntity> connectionOptional = connectionRepository.findById(connectionId);
        if (!connectionOptional.isPresent()) {
            throw new NetworkNotFoundException("No connection found: " + connectionId);
        }
        ConnectionEntity connectionEntity = connectionOptional.get();
        Connection connectionDto = new Connection(connectionEntity.getId(), connectionEntity.getNodeid1(), connectionEntity.getNodeid2(), connectionEntity.getName());
        return connectionDto;
    }

    public Long addConnection(Connection connection, Long networkId) {
        List<ConnectionEntity> networkConnectionList = connectionRepository.findByNetworkid(networkId);

        boolean emptyConnections = dtoValidator.verifyConnectionEmpty(connection, networkConnectionList);
        if (!emptyConnections) {
            throw new AddingConnectionException("Connection already exist, nodeId1: " + connection.getNodeId1() + ", nodeId2: " + connection.getNodeId2());
        }

        ConnectionEntity connectionEntity = dtoBuilder.prepareEntity(connection, networkId);
        ConnectionEntity savedConnectionEntity = connectionRepository.save(connectionEntity);
        return savedConnectionEntity.getId();
    }

    public void addConnectionListSilently(List<Connection> connectionList, Long networkId, Long nodeId) {
        logger.info("Will try to add connectionList, skipping invalid, size: "+connectionList.size() );
        List<NodeEntity> networkNodeList = nodeRepository.findByNetworkid(networkId);
        if (!dtoValidator.validateNodeInNetwork(networkId, nodeId, networkNodeList)) {
            logger.warn("Current NetworkId doesnt contain NodeId: "+ nodeId);
            return;
        }
        List<Connection> validDtos = dtoValidator.filterInvalidDto(connectionList);
        List<Connection> validNetworkDtos = dtoValidator.filterInvalidNodeIdForNetwork(networkNodeList, validDtos);

        List<ConnectionEntity> networkConnectionList = connectionRepository.findByNetworkid(networkId);
        List<ConnectionEntity> conEntities = validNetworkDtos.stream()
                .filter(conDto -> dtoValidator.verifyConnectionEmpty(conDto, networkConnectionList))
                .map(conDto -> dtoBuilder.prepareEntity(conDto, networkId))
                .collect(Collectors.toList());

        dtoValidator.filterDuplicateEntities(conEntities);
        logger.info("Inserting connectionList, size: "+connectionList.size() );
        for (ConnectionEntity entity : conEntities) {
            connectionRepository.save(entity);
        }
    }

    public void updateConnection(Connection connectionDto, Long connectionId) {
        Optional<ConnectionEntity> optional = connectionRepository.findById(connectionId);
        if (!optional.isPresent()) {
            throw new NetworkNotFoundException("No connection found: " + connectionId);
        }
        ConnectionEntity connectionEntity = optional.get();
//        connectionEntity.setNodeid1(connectionDto.getNodeId1());
//        connectionEntity.setNodeid2(connectionDto.getNodeId2());
        connectionEntity.setName(connectionDto.getConnectionName());
        connectionRepository.save(connectionEntity);
    }

    public void deleteConnection(Long connectionId) {
        connectionRepository.deleteById(connectionId);
    }

    public void deleteAllNetworkConnection(Long networkId) {
        connectionRepository.removeByNetworkid(networkId);
    }

    public List<Connection> getNodeConnections(Long nodeId) {
        Optional<NodeEntity> nodeOptional = nodeRepository.findById(nodeId);
        if (!nodeOptional.isPresent()) {
            throw new NetworkNotFoundException("No node found: " + nodeId);
        }
        NodeEntity nodeEntity = nodeOptional.get();
        List<ConnectionEntity> connectionEntityList = connectionRepository.findByNetworkid(nodeEntity.getNetworkid());
        List<ConnectionEntity> nodeConnetions = dtoValidator.filterConnectionsForCurrentNode(connectionEntityList, nodeEntity.getId());
        List<Connection> connectionList = dtoBuilder.mapConnectionEntitiesToDto(nodeConnetions);
        return connectionList;
    }

}
