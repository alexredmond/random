/*
 * Copyright (c) 2018 Mastercard. All rights reserved.
 */

package com.mastercard.labs.network.web.repository;


import com.mastercard.labs.network.web.repository.entity.ConnectionEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ConnectionRepository extends JpaRepository<ConnectionEntity, Long>{

    List<ConnectionEntity> findByNetworkid(Long networkid);

    Long removeByNetworkid(Long networkid);

    Long removeByNodeid1(Long nodeid1);

    Long removeByNodeid2(Long nodeid2);

}
