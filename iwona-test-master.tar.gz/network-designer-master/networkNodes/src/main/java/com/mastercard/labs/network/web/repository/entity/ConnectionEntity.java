/*
 * Copyright (c) 2018 Mastercard. All rights reserved.
 */

package com.mastercard.labs.network.web.repository.entity;


import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

import javax.persistence.*;


@Entity
@Table(name = "Connections")
public class ConnectionEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "connection_generator")
    @SequenceGenerator(name = "connection_generator", sequenceName = "connectionseq", allocationSize = 1)
    private Long id;
    private Long networkid;
    private Long nodeid1;
    private Long nodeid2;
    private String name;


    public ConnectionEntity() {
    }

    public ConnectionEntity(Long id, Long networkid, Long nodeid1, Long nodeid2, String name) {
        this.id = id;
        this.networkid = networkid;
        this.nodeid1 = nodeid1;
        this.nodeid2 = nodeid2;
        this.name = name;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getNetworkid() {
        return networkid;
    }

    public void setNetworkid(Long networkid) {
        this.networkid = networkid;
    }

    public Long getNodeid1() {
        return nodeid1;
    }

    public void setNodeid1(Long nodeid1) {
        this.nodeid1 = nodeid1;
    }

    public Long getNodeid2() {
        return nodeid2;
    }

    public void setNodeid2(Long nodeid2) {
        this.nodeid2 = nodeid2;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this, ToStringStyle.SHORT_PREFIX_STYLE).toString();
    }

}
