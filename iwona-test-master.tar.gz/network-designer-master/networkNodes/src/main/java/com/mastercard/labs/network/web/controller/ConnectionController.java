/*
 * Copyright (c) 2018 Mastercard. All rights reserved.
 */

package com.mastercard.labs.network.web.controller;

import com.mastercard.labs.network.web.businessobject.Connection;
import com.mastercard.labs.network.web.businessobject.Node;
import com.mastercard.labs.network.web.service.NetworkService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import java.net.URI;
import java.util.List;

@RestController
@Api(value = "NetworkNode Management System", description = "NetworkNode - Node Connections")
public class ConnectionController {

    private Logger logger = LoggerFactory.getLogger(this.getClass());

    @Autowired
    private NetworkService networkService;


    @GetMapping("/network/{networkId}/connections")
    @ApiOperation(value = "View list of Network Connections", response = List.class)
    public ResponseEntity<List<Connection>> retrieveConnections(@PathVariable long networkId) {
        try {

            List<Connection> connectionDtoList = networkService.getNetworkConnections(networkId);
            return ResponseEntity.ok(connectionDtoList);

        } catch (Exception e) {
            return ResponseEntity.notFound().build();
        }
    }


    @PostMapping("/network/{networkId}/connection")
    @ApiOperation(value = "Add Connection")
    public ResponseEntity<Long> addConnection(@RequestBody Connection connection, @PathVariable long networkId) {
        try {
            logger.info("Adding Connection: " + connection.toString());
            Long connectionId = networkService.addConnection(connection, networkId);
            return ResponseEntity.ok(connectionId);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.NOT_ACCEPTABLE).body(null);
        }
    }


    @PostMapping("/network/{networkId}/connections")
    @ApiOperation(value = "Add Connection List")
    public ResponseEntity<Object> addConnectionsSilently(@RequestBody List<Connection> connectionList, @PathVariable long networkId) {
        try {
            networkService.addConnectionListSilently(connectionList, networkId, null);
            return ResponseEntity.created(null).build();
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.NOT_ACCEPTABLE).body(null);
        }
    }


    @DeleteMapping("/network/{networkId}/connections")
    @ApiOperation(value = "Delete all Connection")
    public ResponseEntity<Object> deleteAllConnection(@PathVariable long networkId) {
        networkService.deleteAllNetworkConnection(networkId);
        return ResponseEntity.noContent().build();
    }


    @GetMapping("/network/{networkId}/connections/{connectionId}")
    @ApiOperation(value = "View Connection")
    public ResponseEntity<Connection> getConnection(@PathVariable long networkId, @PathVariable long connectionId) {
        try {

            Connection connection = networkService.getConnection(connectionId);
            return ResponseEntity.ok(connection);

        } catch (Exception e) {
            return ResponseEntity.notFound().build();
        }
    }


    @PutMapping("/network/{networkId}/connections/{connectionId}")
    @ApiOperation(value = "Modify Connection")
    public ResponseEntity<Object> updateConnection(@RequestBody Connection connection, @PathVariable long connectionId) {
        try {

            networkService.updateConnection(connection, connectionId);
            return ResponseEntity.noContent().build();

        } catch (Exception e) {
            return ResponseEntity.notFound().build();
        }
    }


    @DeleteMapping("/network/{networkId}/connections/{connectionId}")
    @ApiOperation(value = "Delete Connection")
    public ResponseEntity<Object> deleteConnection(@PathVariable long connectionId) {
        networkService.deleteConnection(connectionId);
        return ResponseEntity.noContent().build();
    }


    @GetMapping("/network/{networkId}/nodes/{nodeId}/connections")
    @ApiOperation(value = "View Node Connections")
    public ResponseEntity<List<Connection>> getNodeConections(@PathVariable long networkId, @PathVariable long nodeId) {
        try {

            List<Connection> connectionList = networkService.getNodeConnections(nodeId);
            return ResponseEntity.ok(connectionList);

        } catch (Exception e) {
            return ResponseEntity.notFound().build();
        }
    }


    @PostMapping("/network/{networkId}/nodes/{nodeId}/connections")
    @ApiOperation(value = "Add Node ConnectionList")
    public ResponseEntity<List<Connection>> addNodeConnections(@RequestBody List<Connection> connectionList, @PathVariable long networkId, @PathVariable long nodeId) {
        try {

            networkService.addConnectionListSilently(connectionList, networkId, nodeId);
            return ResponseEntity.created(null).build();

        } catch (Exception e) {
            return ResponseEntity.notFound().build();
        }
    }


}
