package com.mastercard.labs.network.web.service.builder;

import com.mastercard.labs.network.web.repository.entity.ConnectionEntity;
import com.mastercard.labs.network.web.repository.entity.NodeEntity;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;

import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.*;

public class DtoBuilderTest {

    @InjectMocks
    private DtoBuilder dtoBuilder;

    @Before
    public void initMocks() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    public void prepareConnectionList() {
        List<NodeEntity> nodesCreated =new ArrayList<>();
        nodesCreated.add(new NodeEntity(1L,88L,"a", "d", "n", "pk","nt"));
        nodesCreated.add(new NodeEntity(2L,88L,"a", "d", "n", "pk","nt"));
        nodesCreated.add(new NodeEntity(3L,88L,"a", "d", "n", "pk","nt"));
        nodesCreated.add(new NodeEntity(4L,88L,"a", "d", "n", "pk","nt"));
        nodesCreated.add(new NodeEntity(5L,88L,"a", "d", "n", "pk","nt"));

        List<ConnectionEntity> list = dtoBuilder.prepareConnectionList(nodesCreated, 88L);
        Assert.assertEquals(10, list.size());
    }

}